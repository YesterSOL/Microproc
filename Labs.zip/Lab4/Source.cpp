#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <cmath>
#include <iostream>
using namespace std;

extern "C" double integr(double x);

int main(int argc, char** argv)
{
	double x;
	cout << "Input x= ";
	cin >> x;

	double R = 0.0;
	R = integr(x);
	cout << "Result= " << R << endl;

	return 0;
}

extern "C" double cotan(double z)
{
	double f, cot;
	cot = cos(z) / sin(z);
	f = cbrt(cot);
	return f;
}