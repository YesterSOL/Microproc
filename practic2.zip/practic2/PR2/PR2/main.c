#include <8051.h>
void main()
{
unsigned char i,j,k;
unsigned char massiv [11]=
{
0xC0, //0
0xF9, //1
0xA4, //2
0xB0, //3
0x99, //4
0x92, //5
0x82, //6
0xF8, //7
0x80, //8
0x90, //9
0xFF  //exit
};
unsigned char massiv_2 [9]=
{
1,
9,
2,
8,
3,
7,
4,
6,
5
};

P1=massiv [10];
P3=0;
while(1)
{
	for(i=0;i<10;i++)
	{
		if(P3==0)
		{
			P2=massiv[i];
			for(j=0;j<100;j++)
			continue;
		}
		else
		{
			for(k=0;k<9;k++)
			{
				P2=massiv[massiv_2[k]];
				for(j=0;j<100;j++)
				continue;
			}
		}
	}
}
}
