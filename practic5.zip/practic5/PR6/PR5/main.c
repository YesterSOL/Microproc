#include <8051.h>
void main()
{
unsigned char i,j,k;
unsigned int arr[2] ;
unsigned int arr1[2] ;
unsigned int key_arr[4][4] = {
{0x30,0x31,0x32,0x33},
{0x34,0x35,0x36,0x37},
{0x38,0x39,0x41,0x42},
{0x43,0x44,0x45,0x46}
};
P0 = 0x38;  
P2 = 0x1;  
P2 = 0x0;
P0 = 0x80;
P2 = 0x1;
P2 = 0x0;
P1=0;
P3=0;
while(1)
{
	k = 2;
	for (i=0; i<3; i++)
	{
		P3=0x00;
		P1=0xff;
		arr[0] = P1;
		P1=0x00;
		P3=0xff;
		arr[1] = P3;
		if(i!=0)
		{
			if((arr1[0] == arr[0]) && (arr1[1] == arr[1]) && (arr[0] != 0xff) && (arr[1] != 0xff) && ((arr[1] == 247) || (arr[1] == 251) || (arr[1] == 253) || (arr[1] == 254)) && ((arr[0] == 247) || (arr[0] == 251) || (arr[0] == 253) || (arr[0] == 254)))
			{
				k++;
			}
		}
		arr1[0] = arr[0];
		arr1[1] = arr[1];
	}
	if(k==4)
	{
		if (arr[1] == 247)
		{
			arr[1] = 3;
		}
		else if (arr[1] == 251)
		{
			arr[1] = 2;
		}
		else if (arr[1] == 253)
		{
			arr[1] = 1;
		}
		else if (arr[1] == 254)
		{
			arr[1] = 0;
		}

		if (arr[0] == 247)
		{
			arr[0] = 3;
		}
		else if (arr[0] == 251)
		{
			arr[0] = 2;
		}
		else if (arr[0] == 253)
		{
			arr[0] = 1;
		}
		else if (arr[0] == 254)
		{
			arr[0] = 0;
		}
		P0 = key_arr[arr[0]][arr[1]];
		P2 = 0x3;
		P2 = 0x2;
	}
}
}