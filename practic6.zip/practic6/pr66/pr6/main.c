#include <8051.h> 

void tput(unsigned char c1) 
{ 
	SBUF=c1;  
	while(!TI); 
	TI=0;  
}
void main() 
{ 
	char z; 
	int i; 
	unsigned char *src = (unsigned char *)0x30;
	src[0] = 'm';
	src[1] = 'a';
	src[2] = 't';
	src[3] = 's';
	src[4] = 'o';
	src[5] = 'l';
	src[6] = 'o';
	src[7] = 'd';
	PCON=0x80; 
	for(i=0; i<8; i++) 
	{ 
		ACC=src[i];  
		SCON = 0x88; 
		tput (src[i]); 
	} 
	while(1){} 
}


/*
#include <8051.h>
void tput(unsigned char *src)
{
while(!RI);
src[sizeof(*src)]=SBUF;
RI=0;
}
void main()
{
unsigned char *src= (unsigned char *)0x30;
PCON=0x80;
while(1)
{
SCON = 0x88;
REN=1;
tput(&src);
}
}
*/